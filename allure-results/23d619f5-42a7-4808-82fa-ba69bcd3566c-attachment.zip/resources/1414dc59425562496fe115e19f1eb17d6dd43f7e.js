"use strict";this.default_kevlar_base=this.default_kevlar_base||{};(function(_){var window=this;
try{
_.aY("QlbBce");
var vSb=function(E,r,n){if(E.ytSysTypographyTypestackReference){E=E.ytSysTypographyTypestackReference;if(!ESj||!rva){if(!ESj){Object.assign(nSn,jga);for(var Y=_.g(Object.entries($U$)),v=Y.next();!v.done;v=Y.next()){var L=_.g(v.value);v=L.next().value;L=L.next().value;v in nSn&&(nSn[v]=L)}ESj=!0}rva||(Object.assign(Y20,jga),rva=!0)}E.endsWith("_TALL")||(E.endsWith("_DEFAULT")&&(E=E.slice(0,-8)),E+="_TALL");E=E.replace("YT_SYS_TYPOGRAPHY_TYPESTACK_REFERENCE_","");(r=r()===1?Y20[E]:nSn[E])?(r={font:r},
n=n!=null?n:{},E=n.maxLines,E=E===void 0?0:E,Y=n.noEllipsis,Y=Y===void 0?!1:Y,n=n.noWrap,E>0&&(r.overflow="hidden",r.display="block"),(n===void 0?0:n)?(r["white-space"]="nowrap",Y||(r["text-overflow"]="ellipsis")):E>0&&(r["line-clamp"]=""+E,r["-webkit-line-clamp"]=""+E,Y||(r.display="-webkit-box",r["-webkit-box-orient"]="vertical",r["text-overflow"]="ellipsis",r["white-space"]="normal")),n=r):n=void 0;return n}},$U$={DISPLAY_L_HEAVY_TALL:'700 6.4rem/9rem "YouTube Sans"',
DISPLAY_L_TALL:'300 6.4rem/9rem "YouTube Sans"',DISPLAY_M_HEAVY_TALL:'700 4.8rem/6.6rem "YouTube Sans"',DISPLAY_M_TALL:'300 4.8rem/6.6rem "YouTube Sans"',DISPLAY_S_HEAVY_TALL:'700 3.6rem/5rem "YouTube Sans"',DISPLAY_S_TALL:'300 3.6rem/5rem "YouTube Sans"',DISPLAY_XS_HEAVY_TALL:'700 2.8rem/3.8rem "YouTube Sans"',DISPLAY_XS_TALL:'300 2.8rem/3.8rem "YouTube Sans"',HEADLINE_L_HEAVY_TALL:"900 3.6rem/5rem Roboto",HEADLINE_L_TALL:"700 3.6rem/5rem Roboto",HEADLINE_M_HEAVY_TALL:"900 2.8rem/3.8rem Roboto",
HEADLINE_M_TALL:"700 2.8rem/3.8rem Roboto",HEADLINE_S_HEAVY_TALL:"900 2.4rem/3.2rem Roboto",HEADLINE_S_TALL:"700 2.4rem/3.2rem Roboto",HEADLINE_XS_HEAVY_TALL:"900 2rem/2.8rem Roboto",HEADLINE_XS_TALL:"700 2rem/2.8rem Roboto"};var jga={ACTION_L_HEAVY_TALL:"700 1.6rem/2.2rem Roboto",ACTION_L_TALL:"500 1.6rem/2.2rem Roboto",ACTION_M_HEAVY_TALL:"700 1.4rem/2rem Roboto",ACTION_M_TALL:"500 1.4rem/2rem Roboto",ACTION_S_HEAVY_TALL:"700 1.2rem/1.8rem Roboto",ACTION_S_TALL:"500 1.2rem/1.8rem Roboto",ACTION_XL_HEAVY_TALL:"700 1.8rem/2.6rem Roboto",ACTION_XL_TALL:"500 1.8rem/2.6rem Roboto",ACTION_XS_HEAVY_TALL:"700 1rem/1.6rem Roboto",ACTION_XS_TALL:"500 1rem/1.6rem Roboto",BODY_L_HEAVY_TALL:"500 1.6rem/2.2rem Roboto",BODY_L_TALL:"400 1.6rem/2.2rem Roboto",
BODY_M_HEAVY_TALL:"500 1.4rem/2rem Roboto",BODY_M_TALL:"400 1.4rem/2rem Roboto",BODY_S_HEAVY_TALL:"500 1.2rem/1.8rem Roboto",BODY_S_TALL:"400 1.2rem/1.8rem Roboto",BODY_XL_HEAVY_TALL:"500 1.8rem/2.6rem Roboto",BODY_XL_TALL:"400 1.8rem/2.6rem Roboto",BODY_XS_HEAVY_TALL:"500 1rem/1.6rem Roboto",BODY_XS_TALL:"400 1rem/1.6rem Roboto",DISPLAY_L_HEAVY_TALL:'700 5.6rem/7.8rem "YouTube Sans"',DISPLAY_L_TALL:'300 5.6rem/7.8rem "YouTube Sans"',DISPLAY_M_HEAVY_TALL:'700 4rem/5.4rem "YouTube Sans"',DISPLAY_M_TALL:'300 4rem/5.4rem "YouTube Sans"',
DISPLAY_S_HEAVY_TALL:'700 3.2rem/4.4rem "YouTube Sans"',DISPLAY_S_TALL:'300 3.2rem/4.4rem "YouTube Sans"',DISPLAY_XS_HEAVY_TALL:'700 2.4rem/3.2rem "YouTube Sans"',DISPLAY_XS_TALL:'300 2.4rem/3.2rem "YouTube Sans"',HEADLINE_L_HEAVY_TALL:"900 3.2rem/4.4rem Roboto",HEADLINE_L_TALL:"700 3.2rem/4.4rem Roboto",HEADLINE_M_HEAVY_TALL:"900 2.4rem/3.2rem Roboto",HEADLINE_M_TALL:"700 2.4rem/3.2rem Roboto",HEADLINE_S_HEAVY_TALL:"900 2rem/2.8rem Roboto",HEADLINE_S_TALL:"700 2rem/2.8rem Roboto",HEADLINE_XS_HEAVY_TALL:"900 1.8rem/2.6rem Roboto",
HEADLINE_XS_TALL:"700 1.8rem/2.6rem Roboto"};var nSn={},Y20={},ESj=!1,rva=!1;_.S5l=function(){_.Tl().addProvider({provide:_.a7E,useValue:vSb})};
_.HA();
}catch(e){_._DumpException(e)}
try{
_.aY("De8mUc");
var t8a=function(E){if(E==null?0:E.ytSysColorBaselineReference)return _.g5(E.ytSysColorBaselineReference)};
_.hef=function(){_.Tl().addProvider({provide:_.cPa,useValue:t8a})};
_.HA();
}catch(e){_._DumpException(e)}
}).call(this,this.default_kevlar_base);
// Google Inc.
